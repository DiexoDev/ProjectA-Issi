package com.diegobpz.Issi.com.entity;

public class Catalogo {
    private String imagen;
    private int precio;
    private String nombre;

    public Catalogo(String imagen, int precio, String nombre) {
        this.imagen = imagen;
        this.precio = precio;
        this.nombre = nombre;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}


