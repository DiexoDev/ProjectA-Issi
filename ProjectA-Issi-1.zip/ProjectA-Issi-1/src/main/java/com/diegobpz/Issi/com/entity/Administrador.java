package com.diegobpz.Issi.com.entity;

public class Administrador {
    private String contraseña;

    public Administrador(String contraseña) {
        this.contraseña = contraseña;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String nuevaContraseña) {
        this.contraseña = nuevaContraseña;
    }

}

