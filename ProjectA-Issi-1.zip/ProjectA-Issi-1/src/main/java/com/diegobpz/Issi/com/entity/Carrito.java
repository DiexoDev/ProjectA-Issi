package com.diegobpz.Issi.com.entity;

public class Carrito {
    private String id;
    private String cantidad;
    private int precio;
    private String fecha_entrega;

    public Carrito(String id, String cantidad, int precio, String fecha_entrega) {
        this.id = id;
        this.cantidad = cantidad;
        this.precio = precio;
        this.fecha_entrega = fecha_entrega;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCantidad() {
        return cantidad;
    }

    public void setCantidad(String cantidad) {
        this.cantidad = cantidad;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public String getFecha_entrega() {
        return fecha_entrega;
    }

    public void setFecha_entrega(String fecha_entrega) {
        this.fecha_entrega = fecha_entrega;
    }
}
